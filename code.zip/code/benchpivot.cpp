#include <vector>
#include <iostream>
#include <chrono>
#include <assert.h>
#include <algorithm>
#include <functional>
#include <string>
#include <fstream>
#include "test_helpers.h"
#include "parallel/combinations.h"
#include "instest.h"

#define NUM_TESTS 10

using seq_fn = int (*) (std::vector<int> &);

struct benchmark {
    std::string filename;
    std::string title;
    std::string x_label;
    std::string y_label;
    int num_curves;
    std::vector<std::string> cs;
    std::vector<seq_fn> fcs;
    void (*test) (seq_fn, int, std::ofstream &);
};

void test_perf(seq_fn fn, int num_elements, std::ofstream &file) {
    unsigned long total = 0L;
    for (int i = 0; i < NUM_TESTS; i++) {
        int ind;
        std::vector<int> a;
        push_random(a, num_elements);
        auto start = std::chrono::high_resolution_clock::now();
        ind = fn(a);
        auto end = std::chrono::high_resolution_clock::now();
        total +=
            std::chrono::duration_cast<std::chrono::nanoseconds>(end-start)
            .count();
        a.clear();
        a.shrink_to_fit();
    }
    file << total / NUM_TESTS << " ";
}

void split(std::vector<int> data, int pivot,
        std::vector<int> l, std::vector<int> r) {
    std::swap(data[0], data[pivot]);
    for (int i = 1; i < data.size(); i++) {
        if (data[i] < pivot) {
            l.push_back(data[i]);
        } else {
            r.push_back(data[i]);
        }
    }
}

void test_split(seq_fn fn, int num_elements, std::ofstream &file) {
    unsigned long total = 0L;
    for (int i = 0; i < NUM_TESTS; i++) {
        int ind;
        std::vector<int> a, l, r;
        push_random(a, num_elements);
        ind = fn(a);
        split(a, ind, l, r);
        int diff = l.size() - r.size();
        total += std::abs(diff);
        a.clear();
        a.shrink_to_fit();
        l.clear();
        l.shrink_to_fit();
        r.clear();
        r.shrink_to_fit();
    }
    file << total / NUM_TESTS << " ";
}

void run_benchmark(benchmark bench) {
    // Prepare the file
    std::ofstream file;
    file.open(bench.filename);

    // Write the information
    file << bench.title << std::endl;
    file << bench.x_label << std::endl;
    file << bench.y_label << std::endl;
    file << bench.num_curves << std::endl;
    for (int i = 0; i < bench.num_curves; i++) {
        file << bench.cs[i] << std::endl;
    }

    // Run the benchmark
    for (int i = 1; i <= 10000; i *= 10) {
        for (int n = 2; n <= 10; n++) {
            file << i*n << " ";
            for (int j = 0; j < bench.num_curves; j++) {
                bench.test(bench.fcs[j], i * n, file);
            }
            file << std::endl;
        }
    }

    // Close the file
    file.close();
}

int main() {
    // The vector holding all of the benchmarks
    std::vector<benchmark> benchs;

    {
        benchmark bench;
        bench.filename = "results/pivot_perf";
        bench.title = "Pivot choosing";
        bench.x_label = "Number of elements";
        bench.y_label = "Avererage nanoseconds";
        bench.num_curves = 3;
        bench.cs.push_back("random");
        bench.cs.push_back("middle");
        bench.cs.push_back("median of three");
        bench.fcs.push_back(rand_pivot);
        bench.fcs.push_back(middle_pivot);
        bench.fcs.push_back(median_of_three_pivot);
        bench.test = test_perf;
        benchs.push_back(bench);
    }

    {
        benchmark bench;
        bench.filename = "results/pivot_split";
        bench.title = "Pivot choosing";
        bench.x_label = "Number of elements";
        bench.y_label = "Avererage difference in split sizes";
        bench.num_curves = 3;
        bench.cs.push_back("random");
        bench.cs.push_back("middle");
        bench.cs.push_back("median of three");
        bench.fcs.push_back(rand_pivot);
        bench.fcs.push_back(middle_pivot);
        bench.fcs.push_back(median_of_three_pivot);
        bench.test = test_perf;
        benchs.push_back(bench);
    }

    for (int i = 0; i < benchs.size(); i++) {
        run_benchmark(benchs[i]);
    }
}
