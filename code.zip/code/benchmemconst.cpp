#include <vector>
#include <iostream>
#include <chrono>
#include <assert.h>
#include <algorithm>
#include <functional>
#include <string>
#include <fstream>
#include "test_helpers.h"
#include "parallel/combinations.h"
#include "instest.h"

#define NUM_TESTS 10

using seq_fn = void (*) (std::vector<int> &, int, int);

struct benchmark {
    std::string filename;
    std::string title;
    std::string x_label;
    std::string y_label;
    int num_curves;
    std::vector<std::string> cs;
    std::vector<seq_fn> fcs;
    void (*test) (seq_fn, int, std::ofstream &);
};

void test_seq(seq_fn fn, int num_elements, std::ofstream &file) {
    unsigned long total = 0L;
    for (int i = 0; i < NUM_TESTS; i++) {
        std::vector<int> a;
        push_random(a, num_elements);
        int cutoff = num_elements / 3;
        int begin = cutoff, stop = num_elements - cutoff;
        auto start = std::chrono::high_resolution_clock::now();
        fn(a, begin, stop);
        auto end = std::chrono::high_resolution_clock::now();
        total +=
            std::chrono::duration_cast<std::chrono::nanoseconds>(end-start)
            .count();
        a.clear();
        a.shrink_to_fit();
    }
    file << total / NUM_TESTS << " ";
}

void run_benchmark(benchmark bench) {
    // Prepare the file
    std::ofstream file;
    file.open(bench.filename);

    // Write the information
    file << bench.title << std::endl;
    file << bench.x_label << std::endl;
    file << bench.y_label << std::endl;
    file << bench.num_curves << std::endl;
    for (int i = 0; i < bench.num_curves; i++) {
        file << bench.cs[i] << std::endl;
    }

    // Run the benchmark
    for (int i = 1; i <= 100000; i *= 10) {
        for (int n = 2; n <= 10; n++) {
            file << i*n << " ";
            for (int j = 0; j < bench.num_curves; j++) {
                bench.test(bench.fcs[j], i * n, file);
            }
            file << std::endl;
        }
    }

    // Close the file
    file.close();
}

int main() {
    // The vector holding all of the benchmarks
    std::vector<benchmark> benchs;

    {
        benchmark bench;
        bench.filename = "results/memmanempty_constr";
        bench.title = "Memory management into empty";
        bench.x_label = "Number of elements";
        bench.y_label = "Avererage nanoseconds";
        bench.num_curves = 2;
        bench.cs.push_back("constructor");
        bench.cs.push_back("insert reserved");
        bench.fcs.push_back(get_sub_constructor);
        bench.fcs.push_back(get_sub_cpy);
        bench.test = test_seq;
        benchs.push_back(bench);
    }

    for (int i = 0; i < benchs.size(); i++) {
        run_benchmark(benchs[i]);
    }
}
