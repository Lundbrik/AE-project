#include <vector>

void insert(std::vector<int> &a, int count) {
    a.insert(a.begin(), count, count);
}

void insert_reserved(std::vector<int> &a, int count) {
    a.reserve(count);
    a.insert(a.begin(), count, count);
}

void insert_one(std::vector<int> &a, int count) {
    for (int i = 0; i < count; i++) {
        a.insert(a.end(), count);
    }
}

void insert_one_reserved(std::vector<int> &a, int count) {
    a.reserve(count);
    for (int i = 0; i < count; i++) {
        a.insert(a.end(), count);
    }
}

void push_back(std::vector<int> &a, int count) {
    for (int i = 0; i < count; i++) {
        a.push_back(count);
    }
}

void push_back_reserved(std::vector<int> &a, int count) {
    a.reserve(count);
    for (int i = 0; i < count; i++) {
        a.push_back(count);
    }
}

void move(std::vector<int> &a, std::vector<int> &b) {
    for (int i = 0; i < b.size(); i++) {
        a[i] = b[i];
    }
}

void move_reg(std::vector<int> &a, std::vector<int> &b) {
    int size = b.size();
    for (int i = 0; i < size; i++) {
        a[i] = b[i];
    }
}

void move_reg_in(std::vector<int> &a, std::vector<int> &b) {
    int size = b.size();
    int i = 0, j = 0;
    for (; i < size;) {
        a[i++] = b[j++];
    }
}

void move_reg_out(std::vector<int> &a, std::vector<int> &b) {
    int size = b.size();
    int i = 0, j = 0;
    for (; i < size;) {
        a[i] = b[j];
        i++;
        j++;
    }
}

void move_insert(std::vector<int> &a, std::vector<int> &b) {
    a.insert(a.begin(), b.begin(), b.end());
}

void move_insert_reseved(std::vector<int> &a, std::vector<int> &b) {
    a.reserve(b.size());
    a.insert(a.begin(), b.begin(), b.end());
}

void move_insert_one(std::vector<int> &a, std::vector<int> &b) {
    for (int i = 0; i < b.size(); i++) {
        a.insert(a.end(), b[i]);
    }
}

void move_insert_one_reserved(std::vector<int> &a, std::vector<int> &b) {
    a.reserve(b.size());
    for (int i = 0; i < b.size(); i++) {
        a.insert(a.end(), b[i]);
    }
}

void move_push(std::vector<int> &a, std::vector<int> &b) {
    for (int i = 0; i < b.size(); i++) {
        a.push_back(b[i]);
    }
}

void move_push_reserved(std::vector<int> &a, std::vector<int> &b) {
    a.reserve(b.size());
    for (int i = 0; i < b.size(); i++) {
        a.push_back(b[i]);
    }
}

void get_sub_constructor(std::vector<int> &a, int start, int end) {
    std::vector<int> sub (a.begin() + start, a.begin() + end);
}

void get_sub_cpy(std::vector<int> &a, int start, int end) {
    std::vector<int> sub;
    sub.reserve(end - start);
    sub.insert(sub.end(), a.begin() + start, a.begin() + end);
}

int median_of_three_pivot(std::vector<int> &data) {
    int size = data.size();
    int inds[] = {
        rand() % size,
        rand() % size,
        rand() % size
    };
    if (data[inds[0]] < data[inds[1]]) {
        if (data[inds[1]] < data[inds[2]]) {
            return inds[1];
        } else {
            return inds[0] < inds[2] ? inds[2] : inds[0];
        }
    } else {
        if (data[inds[0]] < data[inds[2]]) {
            return inds[0];
        } else {
            return inds[1] < inds[2] ? inds[2] : inds[1];
        }
    }
}

int rand_pivot(std::vector<int> &data) {
    return rand() % data.size();
}

int middle_pivot(std::vector<int> &data) {
    return data.size() / 2;
}

