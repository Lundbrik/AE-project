#include <thread>
#include <mutex>
#include <queue>
#include "helpers.h"

/**
 * Sequential inplace quicksort
 */
template <class T>
void qs(std::vector<T> &data, int start, int end) {
    if (check_small(data, start, end)) return;
    int pivot = qs_split(data, start, end);
    qs(data, start, pivot);
    qs(data, pivot+1, end);
}

template <class T>
void qs(std::vector<T> &data) {
    qs(data, 0, data.size());
}

/**
 * Quicksort mem
 */
template <class T>
void qs_mem(std::vector<T> &data) {
    // Check if we are small enough so we dont need to split
    //if (check_small(&data[0], 0, data.size()-1)) return;
    if (check_small(data)) return;

    // Allocate the two resulting vectors
    std::vector<T> left, right;
    left.reserve(data.size() / 2 + 1);
    right.reserve(data.size() / 2 + 1);

    T pivot = qs_mem_split(data, left, right);
    qs_mem(left);
    qs_mem(right);
    int i = 0;
    int size = left.size();
    for (; i < size; i++) {
        data[i] = left[i];
    }
    data[i] = pivot;
    i++;
    size = right.size();
    for (int j = 0; j < size; j++) {
        data[i+j] = right[j];
    }
}

/**
 * Quicksort mem until small enough
 */
template <class T>
void qs_mem_small(std::vector<T> &data) {
    if (data.size() <= 16) {
        run_nsort(data);
        return;
    }
    std::vector<T> left, right;
    left.reserve(data.size() / 2 + 1);
    right.reserve(data.size() / 2 + 1);

    T pivot = qs_mem_split(data, left, right);
    qs_mem_small(left);
    qs_mem_small(right);
    int i = 0;
    for (; i < left.size(); i++) {
        data[i] = left[i];
    }
    data[i] = pivot;
    i++;
    for (int j = 0; j < right.size(); j++) {
        data[i+j] = right[j];
    }
}

/**
 * Quicksort until small enough, then split into seperate memory
 * usefull for using network sort, which uses seperate vector
 */
template <class T>
void qs_small(std::vector<T> &data, int start, int end) {
    if (check_small_small(data, start, end)) return;
    int pivot = qs_split(data, start, end);
    qs_small(data, start, pivot);
    qs_small(data, pivot+1, end);
}

template <class T>
void qs_small(std::vector<T> &data) {
    qs_small<T>(data, 0, data.size());
}

/**
 * Naive parallel quicksort
 */
template <class T>
void qs_nav(T *data, int start, int end) {
    if (check_small(data, start, end)) return;
    int pivot = qs_split(data, start, end-1);
    std::thread t1(qs_nav<T>, data, start, pivot-1);
    std::thread t2(qs_nav<T>, data, pivot+1, end);
    t1.join();
    t2.join();
}

template <class T>
void qs_nav(std::vector<T>& data, int start, int end) {
    qs_nav<T>(&data[0], start, end);
}

/**
 * Thoughtfull with global integer indicating threads available
 */
template <class T>
void qs_num_thr2(T* data, int start, int end, int* cores, std::mutex &mtx) {
    if (check_small(data, start, end)) return;
    int pivot = qs_split(data, start, end);
    mtx.lock();
    if (cores[0] <= 1) {
        mtx.unlock();
        qs_num_thr2(data, start, pivot, cores, mtx);
        qs_num_thr2(data, pivot, end, cores, mtx);
    } else {
        cores[0] -= 2;
        mtx.unlock();
        std::thread t1(qs_num_thr2<T>, data, start, pivot, cores, std::ref(mtx));
        std::thread t2(qs_num_thr2<T>, data, pivot, end, cores, std::ref(mtx));
        t1.join();
        t2.join();
        mtx.lock();
        cores[0] += 2;
        mtx.unlock();
    }
}

template <class T>
void qs_num_thr2(std::vector<T> &data, int cores) {
    std::mutex mtx;
    qs_num_thr2<T>(&data[0], 0, data.size(), &cores, mtx);
}

/**
 * More thoughtfull approach. Only creates as many threads as the machine has
 * cores.
 * Prone to be bad on unstable splits, and as such, idle threads
 */
template <class T>
void qs_num_thr(std::vector<T> &data, int start, int end, int cores) {
    if (check_small(data, start, end)) return;
    int pivot = qs_split(data, start, end);
    if (cores == 1) {
        qs(data, start, pivot);
        qs(data, pivot, end);
    } else {
        std::thread t1(qs_num_thr<T>, std::ref(data), start, pivot, cores/2);
        std::thread t2(qs_num_thr<T>, std::ref(data), pivot, end, cores/2);
        t1.join();
        t2.join();
    }
}

template <class T>
void qs_num_thr(std::vector<T>& data, int cores) {
    qs_num_thr<T>(data, 0, data.size(), cores);
}

/**
 * Thoughtful mem
 */
template <class T>
void qs_num_thr_mem(std::vector<T> &data, int cores) {
    if (check_small(data)) return;

    // Allocate the two resulting vectors
    std::vector<T> left, right;
    left.reserve(data.size() / 2 + 1);
    right.reserve(data.size() / 2 + 1);

    T pivot = qs_mem_split(data, left, right);

     if (cores == 1) {
        qs(left);
        qs(right);
    } else {
        std::thread t1(qs_num_thr_mem<T>, std::ref(left), cores/2);
        std::thread t2(qs_num_thr_mem<T>, std::ref(right), cores/2);
        t1.join();
        t2.join();
    }

    int i = 0;
    for (; i < left.size(); i++) {
        data[i] = left[i];
    }
    data[i] = pivot;
    i++;
    for (int j = 0; j < right.size(); j++) {
        data[i+j] = right[j];
    }

}

/**
 * Thread pool approach
 * I do think its bad performance is due to memory management
 * Does work ok on large input
 */
template <class T>
void qs_pool_worker(T* data, std::queue<int*> &queue, std::mutex &mutex,
        bool &bottom_reached) {
    int *index;
    while (true) {
        if (mutex.try_lock()) {
            if (queue.empty()) {
                if (bottom_reached) {
                    mutex.unlock();
                    return;
                }
                mutex.unlock();
            } else {
                index = queue.front();
                queue.pop();
                mutex.unlock();
                if (!check_small(data, index[0], index[1])) {
                    int pivot = qs_split(data, index[0], index[1]);
                    int *tmpl = (int*) malloc(2 * sizeof(int));
                    tmpl[0] = index[0];
                    tmpl[1] = pivot;
                    int *tmpr = (int*) malloc(2 * sizeof(int));
                    tmpr[0] = pivot+1;
                    tmpr[1] = index[1];
                    mutex.lock();
                    queue.push(tmpl);
                    queue.push(tmpr);
                    mutex.unlock();
                    free(index);
                } else {
                    mutex.lock();
                    bottom_reached = true;
                    mutex.unlock();
                    free(index);
                }
            }
        }
    }
}

template <class T>
void qs_pool(T* data, int start, int end, int cores) {
    // Initialize the queue and put the initial element
    std::queue<int*> qu;
    int* tmp = (int*) malloc(2 * sizeof(int));
    tmp[0] = start;
    tmp[1] = end;
    qu.push(tmp);

    // Declare the mutex, stopping condition and initialize the threads
    std::mutex mtx;
    bool bottom_reached = false;
    std::thread threads[cores];
    for (int i = 0; i < cores; i++) {
        threads[i] = std::thread(qs_pool_worker<T>, data, std::ref(qu),
                std::ref(mtx), std::ref(bottom_reached));
    }

    // Join the threads
    for (int i = 0; i < cores; i++) {
        threads[i].join();
    }
}

template <class T>
void qs_pool(std::vector<T> &data, int cores) {
    qs_pool(&data[0], 0, data.size(), cores);
}

