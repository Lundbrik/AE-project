#ifndef HELPER
#define HELPER
#include <vector>
#include <stdlib.h>
#include "../nsort.h"

template <class T>
int median_of_three(T* data, int start, int end) {
    int inds[] = {
        rand() % (end - start) + start,
        rand() % (end - start) + start,
        rand() % (end - start) + start
    };
    if (data[inds[0]] < data[inds[1]]) {
        if (data[inds[1]] < data[inds[2]]) {
            return inds[1];
        } else {
            return inds[0] < inds[2] ? inds[2] : inds[0];
        }
    } else {
        if (data[inds[0]] < data[inds[2]]) {
            return inds[0];
        } else {
            return inds[1] < inds[2] ? inds[2] : inds[1];
        }
    }
}

template <class T>
int median_of_three(std::vector<T> &data, int start, int end) {
    int inds[] = {
        rand() % (end - start) + start,
        rand() % (end - start) + start,
        rand() % (end - start) + start
    };
    if (data[inds[0]] < data[inds[1]]) {
        if (data[inds[1]] < data[inds[2]]) {
            return inds[1];
        } else {
            return inds[0] < inds[2] ? inds[2] : inds[0];
        }
    } else {
        if (data[inds[0]] < data[inds[2]]) {
            return inds[0];
        } else {
            return inds[1] < inds[2] ? inds[2] : inds[1];
        }
    }
}

template <class T>
int qs_split(T *data, int start, int end) {
    int pivot = (end - start) / 2 + start;

    std::swap(data[start], data[pivot]); // Move pivot to start
    int i = start + 1, j = end-1;
    while (i < j) {
        if (data[i] > data[start]) {
            std::swap(data[i], data[j]);
            j--;
        } else {
            i++;
        }
    }
    if (data[start] > data[i]) {
        pivot = i;
    } else {
        pivot = i-1;
    }
    std::swap(data[start], data[pivot]); // Move pivot back
    return pivot;
}

template <class T>
int qs_split(std::vector<T> &data, int start, int end) {
    int pivot = (end - start) / 2 + start;
    std::swap(data[start], data[pivot]); // Move pivot to start
    int i = start + 1, j = end-1;
    while (i < j) {
        if (data[i] > data[start]) {
            std::swap(data[i], data[j]);
            j--;
        } else {
            i++;
        }
    }
    if (data[start] > data[i]) {
        pivot = i;
    } else {
        pivot = i-1;
    }
    std::swap(data[start], data[pivot]); // Move pivot back
    return pivot;
}

// Splits data into left and right, returns pivot, and clears input data
// No need to shrink vector, as it will hold the result, which is the same size
// as the input
template <class T>
T qs_mem_split(std::vector<T> &data, std::vector<T> &left,
        std::vector<T> &right) {
    int size = data.size();
    int pivot_index = size / 2;
    std::swap(data[0], data[pivot_index]);
    T pivot = data[0];
    for (int i = 1; i < size; i++) {
        if (data[i] < pivot) {
            left.insert(left.end(), data[i]);
        } else {
            right.insert(right.end(), data[i]);
        }
    }
    return pivot;
}

template <class T>
bool check_small(T *data, int start, int end) {
    int size = end - start;
    if (size < 3) { // 2 or less elements
        if (size == 2 && data[start] > data[start+1]) {
            std::swap(data[start], data[start+1]);
        }
        return true;
    }
    return false;
}

template <class T>
bool check_small(std::vector<T> &data, int start, int end) {
    int size = end - start;
    if (size < 3) { // 2 or less elements
        if (size == 2 && data[start] > data[start+1]) {
            std::swap(data[start], data[start+1]);
        }
        return true;
    }
    return false;
}

template <class T>
bool check_small(std::vector<T> &data) {
    if (data.size() < 3) { // 2 or less elements
        if (data.size() == 2 && data[0] > data[1]) {
            std::swap(data[0], data[1]);
        }
        return true;
    }
    return false;
}

template <class T>
void run_nsort(std::vector<T> &data) {
    switch (data.size()) {
        case 2: nsort_2(data);
                break;
        case 3: nsort_3(data);
                break;
        case 4: nsort_4(data);
                break;
        case 5: nsort_5(data);
                break;
        case 6: nsort_6(data);
                break;
        case 7: nsort_7(data);
                break;
        case 8: nsort_8(data);
                break;
        case 9: nsort_9(data);
                break;
        case 10: nsort_10(data);
                 break;
        case 11: nsort_11(data);
                 break;
        case 12: nsort_12(data);
                 break;
        case 13: nsort_13(data);
                 break;
        case 14: nsort_14(data);
                 break;
        case 15: nsort_15(data);
                break;
        case 16: nsort_16(data);
                break;
        default: break;
    }
}

template <class T>
bool check_small_small(std::vector<T> &data, int start, int end) {
    int size = end - start;
    if (size <= 16) {
        if (size >= 2) {
            std::vector<T> tmp (data.begin() + start, data.begin() + end);
            run_nsort(tmp);
            for (int i = 0; i < size; i++) {
                data[start + i] = tmp[i];
            }
        }
        return true;
    }
    return false;
}
#endif
