#include <thread>
#include "helpers.h"

/**
 * Mergesort
 */
template <class T>
void merge(std::vector<T> &data, int l1, int l2, int end) {
    std::vector<T> tmp(data.begin() + l1, data.begin() + l2);
    int i = 0, j = l2, cur = l1;
    while (i+l1 < l2 && j < end) {
        if (tmp[i] < data[j]) {
            data[cur] = tmp[i];
            i++;
        } else {
            data[cur] = data[j];
            j++;
        }
        cur++;
    }
    if (i == l2) {
        // move remaining j's. Should already be in the right place
    } else if (j == end) {
        int size = tmp.size();
        for (; i < size; i++) {
            data[cur] = tmp[i];
            cur++;
        }
    }
}

template <class T>
//void mergesort(T* data, int start, int end) {
void mergesort(std::vector<T> &data, int start, int end) {
    if (start == end-1) {
        return;
    }
    int mid = ((end - start) / 2) + start;
    mergesort(data, start, mid);
    mergesort(data, mid, end);
    merge(data, start, mid, end);
}

template <class T>
void mergesort(std::vector<T> &data) {
    mergesort<T>(data, 0, data.size());
}


/**
 * Mergesort independant memory
 */
template <class T>
void merge_mem(std::vector<T> &left, std::vector<T> &right, std::vector<T> &res) {
    int lsize = left.size(), rsize = right.size();
    int i = 0, j = 0, cur = 0;
    while (i < lsize && j < rsize) {
        if (left[i] < right[j]) {
            res[cur++] = left[i++];
        } else {
            res[cur++] = right[j++];
        }
    }
    if (i == lsize) {
        for (; j < rsize; j++) {
            res[cur++] = right[j];
        }
    } else {
        for (; i < lsize; i++) {
            res[cur++] = left[i];
        }
    }
}

template <class T>
void mergesort_mem(std::vector<T> &data) {
    if (data.size() <= 1) {
        return;
    }
    int mid = data.size() / 2;
    std::vector<T> left (data.begin(), data.begin()+mid);
    std::vector<T> right(data.begin()+mid, data.end());
    mergesort_mem(left);
    mergesort_mem(right);
    merge_mem(left, right, data);
}

/**
 * Mergesort mem small
 */
template <class T>
void mergesort_mem_small(std::vector<T> &data) {
    if (data.size() <= 16) {
        run_nsort(data);
        return;
    }
    int mid = data.size() / 2;
    std::vector<T> left(data.begin(), data.begin()+mid);
    std::vector<T> right(data.begin()+mid, data.end());
    mergesort_mem_small(left);
    mergesort_mem_small(right);
    merge_mem(left, right, data);
}

/**
 * Mergesort with nsort
 */
template <class T>
void mergesort_small(std::vector<T> &data, int start, int end) {
    if (check_small_small(data, start, end)) return;
    int mid = ((end - start) / 2) + start;
    mergesort_small(data, start, mid);
    mergesort_small(data, mid, end);
    merge(data, start, mid, end);
}

template <class T>
void mergesort_small(std::vector<T> &data) {
    mergesort_small<T>(data, 0, data.size());
}


/**
 * Parallel mergesort
 * Follows the thoughtfull parallel quicksort
 */
template <class T>
void mergesort_par(std::vector<T> &data, int start, int end, int cores) {
    if (start == end-1) {
        return;
    }
    int mid = ((end - start) / 2) + start;
    if (cores == 1) {
        mergesort(data, start, mid);
        mergesort(data, mid, end);
    } else {
        std::thread t1(mergesort_par<T>, std::ref(data), start, mid, cores/2);
        std::thread t2(mergesort_par<T>, std::ref(data), mid, end, cores/2);
        t1.join();
        t2.join();
    }
    merge(data, start, mid, end);
}

template <class T>
void mergesort_par(std::vector<T> &data, int cores) {
    mergesort_par<T>(data, 0, data.size(), cores);
}

/**
 * Parellel mem mergesort
 */
template <class T>
void mergesort_par_mem(std::vector<T> &data, int cores) {
    if (data.size() <= 1) {
        return;
    }
    int mid = data.size() / 2;
    std::vector<T> left(data.begin(), data.begin()+mid);
    std::vector<T> right(data.begin()+mid, data.end());
    if (cores == 1) {
        mergesort_mem(left);
        mergesort_mem(right);
    } else {
        std::thread t1(mergesort_par_mem<T>, std::ref(left), cores/2);
        std::thread t2(mergesort_par_mem<T>, std::ref(right), cores/2);
        t1.join();
        t2.join();
    }
    merge_mem(left, right, data);
}

/**
 * Parralel mem mergesort with nsort
 */
template <class T>
void mergesort_par_mem_small(std::vector<T> &data, int cores) {
    if (data.size() <= 16) {
        run_nsort(data);
        return;
    }
    int mid = data.size() / 2;
    std::vector<T> left(data.begin(), data.begin()+mid);
    std::vector<T> right(data.begin()+mid, data.end());
    if (cores == 1) {
        mergesort_mem_small(left);
        mergesort_mem_small(right);
    } else {
        std::thread t1(mergesort_par_mem_small<T>, std::ref(left), cores/2);
        std::thread t2(mergesort_par_mem_small<T>, std::ref(right), cores/2);
        t1.join();
        t2.join();
    }
    merge_mem(left, right, data);
}

/**
 * Parallel mergesort with nsort
 */
template <class T>
void mergesort_par_small(std::vector<T> &data, int start, int end, int cores) {
    if (check_small_small(data, start, end)) return;
    int mid = ((end - start) / 2) + start;
    if (cores == 1) {
        mergesort_small(data, start, mid);
        mergesort_small(data, mid, end);
    } else {
        std::thread t1(mergesort_par_small<T>, std::ref(data), start, mid, cores/2);
        std::thread t2(mergesort_par_small<T>, std::ref(data), mid, end, cores/2);
        t1.join();
        t2.join();
    }
    merge(data, start, mid, end);
}

template <class T>
void mergesort_par_small(std::vector<T> &data, int cores) {
    mergesort_par_small<T>(data, 0, data.size(), cores);
}

