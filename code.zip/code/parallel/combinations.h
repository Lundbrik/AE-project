#include <thread>
#include "mergesort.h"
#include "quicksort.h"

/**
 * QuickMerge
 */
template <class T>
void quickmerge(std::vector<T> &data, int start, int end, int cores) {
    if (check_small(data, start, end)) return;
    int mid = ((end - start) / 2) + start;
    if (cores == 1) {
        qs(data, start, mid);
        qs(data, mid, end);
    } else {
        std::thread t1(quickmerge<T>, std::ref(data), start, mid, cores/2);
        std::thread t2(quickmerge<T>, std::ref(data), mid, end, cores/2);
        t1.join();
        t2.join();
    }
    merge(data, start, mid, end);
}

template <class T>
void quickmerge(std::vector<T> &data, int cores) {
    quickmerge<T>(data, 0, data.size(), cores);
}

/**
 * Quickmerge mem
 */
template <class T>
void quickmerge_mem(std::vector<T> &data, int cores) {
     if (data.size() <= 1) {
        return;
    }
    int mid = data.size() / 2;
    std::vector<T> left(data.begin(), data.begin()+mid);
    std::vector<T> right(data.begin()+mid, data.end());
    if (cores == 1) {
        qs(left);
        qs(right);
    } else {
        std::thread t1(mergesort_par_mem<T>, std::ref(left), cores/2);
        std::thread t2(mergesort_par_mem<T>, std::ref(right), cores/2);
        t1.join();
        t2.join();
    }
    merge_mem(left, right, data);
}

/**
 * Quickmerge mem small
 */
template <class T>
void quickmerge_mem_small(std::vector<T> &data, int cores) {
    if (data.size() <= 16) {
        run_nsort(data);
        return;
    }
    int mid = data.size() / 2;
    std::vector<T> left(data.begin(), data.begin()+mid);
    std::vector<T> right(data.begin()+mid, data.end());
    if (cores == 1) {
        qs_small(left);
        qs_small(right);
    } else {
        std::thread t1(mergesort_par_mem<T>, std::ref(left), cores/2);
        std::thread t2(mergesort_par_mem<T>, std::ref(right), cores/2);
        t1.join();
        t2.join();
    }
    merge_mem(left, right, data);
}

/**
 * QuickMerge small
 */
template <class T>
void quickmerge_small(std::vector<T> &data, int start, int end, int cores) {
    if (check_small_small(data, start, end)) return;
    int mid = ((end - start) / 2) + start;
    if (cores == 1) {
        qs_small(data, start, mid);
        qs_small(data, mid, end);
    } else {
        std::thread t1(quickmerge_small<T>, std::ref(data), start, mid, cores/2);
        std::thread t2(quickmerge_small<T>, std::ref(data), mid, end, cores/2);
        t1.join();
        t2.join();
    }
    merge(data, start, mid, end);
}

template <class T>
void quickmerge_small(std::vector<T> &data, int cores) {
    quickmerge_small<T>(data, 0, data.size(), cores);
}
