#include <vector>
#include <iostream>
#include <stdio.h>
#include <chrono>
#include <assert.h>
#include <algorithm>
#include <functional>
#include <string>
#include "test_helpers.h"
#include "parallel/combinations.h"

#define NUM_ELEMENTS 100000
#define NUM_TESTS 10

void test_seq(void (*fn) (std::vector<int> &), std::string name) {
    unsigned long total = 0L;
#pragma omp parallel for
    for (int i = 0; i < NUM_TESTS; i++) {
        std::vector<int> input;
        input.reserve(NUM_ELEMENTS);
        push_random(input, NUM_ELEMENTS);
        auto start = std::chrono::high_resolution_clock::now();
        fn(input);
        auto end = std::chrono::high_resolution_clock::now();
        total +=
            std::chrono::duration_cast<std::chrono::nanoseconds>(end-start)
            .count();
        assert(is_sorted(input));
        input.clear();
        input.shrink_to_fit();
    }
    printf("%3lu ns : Average sequential %s\n",
            (total / NUM_TESTS) / NUM_ELEMENTS, name.c_str());
}

void test_par(void (*fn) (std::vector<int> &, int), std::string name) {
    int num_cores = std::thread::hardware_concurrency();
    unsigned long total = 0L;
    for (int i = 0; i < NUM_TESTS; i++) {
        std::vector<int> input;
        input.reserve(NUM_ELEMENTS);
        push_random(input, NUM_ELEMENTS);
        auto start = std::chrono::high_resolution_clock::now();
        fn(input, num_cores);
        auto end = std::chrono::high_resolution_clock::now();
        total +=
            std::chrono::duration_cast<std::chrono::nanoseconds>(end-start)
            .count();
        assert(is_sorted(input));
        input.clear();
        input.shrink_to_fit();
    }
    printf("%3lu ns : Average parallel %s\n",
            (total / NUM_TESTS) / NUM_ELEMENTS, name.c_str());
}

void test_std() {
    unsigned long total = 0L;
#pragma omp parallel for
    for (int i = 0; i < NUM_TESTS; i++) {
        std::vector<int> input;
        input.reserve(NUM_ELEMENTS);
        push_random(input, NUM_ELEMENTS);
        auto start = std::chrono::high_resolution_clock::now();
        std::sort(input.begin(), input.end());
        auto end = std::chrono::high_resolution_clock::now();
        total +=
            std::chrono::duration_cast<std::chrono::nanoseconds>(end-start)
            .count();
        assert(is_sorted(input));
        input.clear();
        input.shrink_to_fit();
    }
    printf("%3lu ns : Average sequential std\n",
            (total / NUM_TESTS) / NUM_ELEMENTS);
}

int main() {
    printf("Testing %d iterations of %d elements and %d threads\n",
            NUM_TESTS, NUM_ELEMENTS,
            std::thread::hardware_concurrency());
    test_std();

    test_seq(qs, "Quicksort");
    test_seq(qs_mem, "Quicksort mem");
    test_seq(qs_mem_small, "Quicksort mem small");
    test_seq(qs_small, "Quicksort small");
    test_seq(mergesort, "Mergesort");
    test_seq(mergesort_mem, "Mergesort mem");
    test_seq(mergesort_mem_small, "Mergesort mem small");
    test_seq(mergesort_small, "Mergesort small");

    test_par(qs_pool, "Quicksort pooled");
    test_par(qs_num_thr, "Quicksort thoughtfull");
    test_par(qs_num_thr_mem, "Quicksort thoughtfull mem");
    test_par(qs_num_thr2, "Quicksort thoughtfull 2");
    test_par(mergesort_par, "Mergesort");
    test_par(mergesort_par_mem, "Mergesort mem");
    test_par(mergesort_par_mem_small, "Mergesort mem small");
    test_par(mergesort_par_small, "Mergesort small");
    test_par(quickmerge, "Quickmerge");
    test_par(quickmerge_mem, "Quickmerge mem");
    test_par(quickmerge_mem_small, "Quickmerge mem small");
    test_par(quickmerge_small, "Quickmerge small");

}
