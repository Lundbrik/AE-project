#include <vector>
#include <iostream>
#include <chrono>
#include <assert.h>
#include <algorithm>
#include <functional>
#include <string>
#include <fstream>
#include "test_helpers.h"
#include "parallel/combinations.h"
#include "instest.h"

#define NUM_TESTS 10

using seq_fn = void (*) (std::vector<int> &);
using par_fn = void (*) (std::vector<int> &, int);

struct benchmark_seq {
    std::string filename;
    std::string title;
    std::string x_label;
    std::string y_label;
    int num_curves;
    std::vector<std::string> cs;
    std::vector<seq_fn> fcs;
    void (*test) (seq_fn, int, std::ofstream &);
};

struct benchmark_par {
    std::string filename;
    std::string title;
    std::string x_label;
    std::string y_label;
    int num_curves;
    std::vector<std::string> cs;
    std::vector<par_fn> fcs;
    void (*test) (par_fn, int, std::ofstream &);
};

void test_seq(seq_fn fn, int num_elements, std::ofstream &file) {
    unsigned long total = 0L;
    for (int i = 0; i < NUM_TESTS; i++) {
        std::vector<int> a;
        push_random(a, num_elements);
        auto start = std::chrono::high_resolution_clock::now();
        fn(a);
        auto end = std::chrono::high_resolution_clock::now();
        total +=
            std::chrono::duration_cast<std::chrono::nanoseconds>(end-start)
            .count();
        assert(is_sorted(a));
        a.clear();
        a.shrink_to_fit();
    }
    file << (total / NUM_TESTS) / num_elements << " ";
}

void test_par(par_fn fn, int num_elements, std::ofstream &file) {
    int num_cores = std::thread::hardware_concurrency();
    unsigned long total = 0L;
    for (int i = 0; i < NUM_TESTS; i++) {
        std::vector<int> a;
        push_random(a, num_elements);
        auto start = std::chrono::high_resolution_clock::now();
        fn(a, num_cores);
        auto end = std::chrono::high_resolution_clock::now();
        total +=
            std::chrono::duration_cast<std::chrono::nanoseconds>(end-start)
            .count();
        assert(is_sorted(a));
        a.clear();
        a.shrink_to_fit();
    }
    file << (total / NUM_TESTS) / num_elements << " ";
}

void test_std(int num_elements, std::ofstream &file) {
    unsigned long total = 0L;
    for (int i = 0; i < NUM_TESTS; i++) {
        std::vector<int> a;
        push_random(a, num_elements);
        auto start = std::chrono::high_resolution_clock::now();
        std::sort(a.begin(), a.end());
        auto end = std::chrono::high_resolution_clock::now();
        total +=
            std::chrono::duration_cast<std::chrono::nanoseconds>(end-start)
            .count();
        assert(is_sorted(a));
        a.clear();
        a.shrink_to_fit();
    }
    file << (total / NUM_TESTS) / num_elements << " ";
}

void run_benchmark_seq(benchmark_seq bench) {
    // Prepare the file
    std::ofstream file;
    file.open(bench.filename);

    // Write the information
    file << bench.title << std::endl;
    file << bench.x_label << std::endl;
    file << bench.y_label << std::endl;
    file << bench.num_curves + 1 << std::endl;
    file << "std" << std::endl;
    for (int i = 0; i < bench.num_curves; i++) {
        file << bench.cs[i] << std::endl;
    }

    // Run the benchmark
    for (int i = 1; i <= 1000000; i *= 10) {
        for (int n = 2; n <= 10; n++) {
            file << i*n << " ";
            test_std(i*n, file);
            for (int j = 0; j < bench.num_curves; j++) {
                bench.test(bench.fcs[j], i * n, file);
            }
            file << std::endl;
        }
    }

    // Close the file
    file.close();
}

void run_benchmark_par(benchmark_par bench) {
    // Prepare the file
    std::ofstream file;
    file.open(bench.filename);

    // Write the information
    file << bench.title << std::endl;
    file << bench.x_label << std::endl;
    file << bench.y_label << std::endl;
    file << bench.num_curves + 1 << std::endl;
    file << "std" << std::endl;
    for (int i = 0; i < bench.num_curves; i++) {
        file << bench.cs[i] << std::endl;
    }

    // Run the benchmark
    for (int i = 100000; i <= 10000000; i *= 10) {
        for (int n = 2; n <= 10; n++) {
            file << i*n << " ";
            test_std(i*n, file);
            for (int j = 0; j < bench.num_curves; j++) {
                bench.test(bench.fcs[j], i * n, file);
            }
            file << std::endl;
        }
    }

    // Close the file
    file.close();
}

int main() {
    // The vector holding all of the benchmarks
    std::vector<benchmark_seq> seq_benchs;

    {
        benchmark_seq bench;
        bench.filename = "results/sequential_sort";
        bench.title = "Sequential sort";
        bench.x_label = "Number of elements";
        bench.y_label = "Avererage nanoseconds per element";
        bench.num_curves = 4;
        bench.cs.push_back("Quicksort");
        bench.cs.push_back("Quicksort small");
        bench.cs.push_back("Mergesort");
        bench.cs.push_back("Mergesort small");
        bench.fcs.push_back(qs);
        bench.fcs.push_back(qs_small);
        bench.fcs.push_back(mergesort);
        bench.fcs.push_back(mergesort_small);
        bench.test = test_seq;
        seq_benchs.push_back(bench);
    }

    for (int i = 0; i < seq_benchs.size(); i++) {
        run_benchmark_seq(seq_benchs[i]);
    }

    std::vector<benchmark_par> par_benchs;
    {
        benchmark_par bench;
        bench.filename = "results/parallel_sort";
        bench.title = "Parallel sort";
        bench.x_label = "Number of elements";
        bench.y_label = "Avererage nanoseconds per element";
        bench.num_curves = 7;
        bench.cs.push_back("Quicksort num thr");
        bench.cs.push_back("Quicksort num thr mem");
        bench.cs.push_back("Quicksort num thr 2");
        //bench.cs.push_back("Quicksort pooled");
        bench.cs.push_back("Mergesort");
        bench.cs.push_back("Mergesort mem");
        bench.cs.push_back("Mergesort mem small");
        bench.cs.push_back("Mergesort small");
        bench.fcs.push_back(qs_num_thr);
        bench.fcs.push_back(qs_num_thr_mem);
        bench.fcs.push_back(qs_num_thr2);
        //bench.fcs.push_back(qs_pool);
        bench.fcs.push_back(mergesort_par);
        bench.fcs.push_back(mergesort_par_mem);
        bench.fcs.push_back(mergesort_par_mem_small);
        bench.fcs.push_back(mergesort_par_small);
        bench.test = test_par;
        par_benchs.push_back(bench);
    }

    {
        benchmark_par bench;
        bench.filename = "results/parallel_sort_mq";
        bench.title = "Parallel sort";
        bench.x_label = "Number of elements";
        bench.y_label = "Avererage nanoseconds per element";
        bench.num_curves = 4;
        bench.cs.push_back("Mergequick");
        bench.cs.push_back("Mergequick mem");
        bench.cs.push_back("Mergequick mem small");
        bench.cs.push_back("Mergequick small");
        bench.fcs.push_back(quickmerge);
        bench.fcs.push_back(quickmerge_mem);
        bench.fcs.push_back(quickmerge_mem_small);
        bench.fcs.push_back(quickmerge_small);
        bench.test = test_par;
        par_benchs.push_back(bench);
    }

    {
        benchmark_par bench;
        bench.filename = "results/parallel_sort_best";
        bench.title = "Parallel sort";
        bench.x_label = "Number of elements";
        bench.y_label = "Avererage nanoseconds per element";
        bench.num_curves = 2;
        bench.cs.push_back("Mergequick small");
        bench.cs.push_back("Mergesort small");
        bench.fcs.push_back(quickmerge_small);
        bench.fcs.push_back(mergesort_par_small);
        bench.test = test_par;
        par_benchs.push_back(bench);
    }

    for (int i = 0; i < par_benchs.size(); i++) {
        run_benchmark_par(par_benchs[i]);
    }

}
